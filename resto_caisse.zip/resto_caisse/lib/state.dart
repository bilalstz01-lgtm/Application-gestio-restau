import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  Restaurant? resto;
  List<Item> items = [];
  final Map<String, int> cart = {};
  int orderNo = 0;
  String? printerMac, printerName;
  bool paper58 = true;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final r = _p.getString('resto');
    if (r != null) resto = Restaurant.fromJson(jsonDecode(r));
    final it = _p.getString('items');
    if (it != null) {
      items = (jsonDecode(it) as List).map((e) => Item.fromJson(e)).toList();
    }
    orderNo = _p.getInt('orderNo') ?? 0;
    printerMac = _p.getString('pMac');
    printerName = _p.getString('pName');
    paper58 = _p.getBool('paper58') ?? true;
  }

  Future<void> saveResto(Restaurant r) async {
    resto = r;
    await _p.setString('resto', jsonEncode(r.toJson()));
    notifyListeners();
  }

  Future<void> _saveItems() async {
    await _p.setString('items', jsonEncode(items.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  Future<void> upsertItem(Item i) async {
    final k = items.indexWhere((e) => e.id == i.id);
    if (k >= 0) {
      items[k] = i;
    } else {
      items.add(i);
    }
    await _saveItems();
  }

  Future<void> deleteItem(String id) async {
    items.removeWhere((e) => e.id == id);
    cart.remove(id);
    await _saveItems();
  }

  void add(Item i) {
    cart[i.id] = (cart[i.id] ?? 0) + 1;
    notifyListeners();
  }

  void dec(Item i) {
    final q = (cart[i.id] ?? 0) - 1;
    if (q <= 0) {
      cart.remove(i.id);
    } else {
      cart[i.id] = q;
    }
    notifyListeners();
  }

  List<Line> get lines => items
      .where((i) => cart.containsKey(i.id))
      .map((i) => Line(i.name, i.price, cart[i.id]!))
      .toList();
  double get total => lines.fold<double>(0, (s, l) => s + l.total);
  int get count => cart.values.fold(0, (a, b) => a + b);

  Order validate() {
    orderNo++;
    _p.setInt('orderNo', orderNo);
    final o = Order(orderNo, DateTime.now(), lines);
    cart.clear();
    notifyListeners();
    return o;
  }

  Future<void> setPrinter(String mac, String name) async {
    printerMac = mac;
    printerName = name;
    await _p.setString('pMac', mac);
    await _p.setString('pName', name);
    notifyListeners();
  }

  Future<void> setPaper58(bool v) async {
    paper58 = v;
    await _p.setBool('paper58', v);
    notifyListeners();
  }
}

final app = AppState();
String money(double v) => '${v.toStringAsFixed(2)} ${app.resto?.currency ?? ''}'.trim();
