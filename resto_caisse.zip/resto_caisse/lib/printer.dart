import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:printing/printing.dart';
import 'models.dart';
import 'state.dart';

const _m = {
  'à': 'a', 'â': 'a', 'ä': 'a', 'á': 'a', 'ã': 'a', 'ç': 'c', 'é': 'e', 'è': 'e',
  'ê': 'e', 'ë': 'e', 'í': 'i', 'î': 'i', 'ï': 'i', 'ñ': 'n', 'ó': 'o', 'ô': 'o',
  'ö': 'o', 'ú': 'u', 'ù': 'u', 'û': 'u', 'ü': 'u', 'œ': 'oe', 'À': 'A', 'Â': 'A',
  'Ç': 'C', 'É': 'E', 'È': 'E', 'Ê': 'E', 'Î': 'I', 'Ô': 'O', 'Ù': 'U', 'Û': 'U',
  '€': 'EUR', '°': 'o',
};
String noAccent(String s) => s.split('').map((c) => _m[c] ?? c).join();

/// Construit le ticket en lignes de texte (w = 32 pour 58 mm, 48 pour 80 mm).
List<String> buildTicket(Order o, Restaurant r, int w, {bool ascii = false}) {
  String t(String s) => ascii ? noAccent(s) : s;
  final cur = t(r.currency);
  String mny(double v) => '${v.toStringAsFixed(2)} $cur'.trim();
  String c(String s) => s.length >= w ? s : ' ' * ((w - s.length) ~/ 2) + s;
  String lr(String left, String right) {
    final sp = w - left.length - right.length;
    if (sp < 1) {
      final cut = (w - right.length - 1).clamp(0, left.length);
      return '${left.substring(0, cut)} $right';
    }
    return left + ' ' * sp + right;
  }

  List<String> wrap(String s) {
    final out = <String>[];
    var cur = '';
    for (final word in s.split(' ')) {
      if ((cur + ' ' + word).trim().length > w) {
        if (cur.isNotEmpty) out.add(cur);
        cur = word;
      } else {
        cur = (cur + ' ' + word).trim();
      }
    }
    if (cur.isNotEmpty) out.add(cur);
    return out;
  }

  final sep = '-' * w;
  final out = <String>[];
  for (final l in wrap(t(r.name).toUpperCase())) out.add(c(l));
  for (final l in wrap(t(r.address))) out.add(c(l));
  if (r.phone.isNotEmpty) out.add(c('Tel: ${t(r.phone)}'));
  out.add(sep);
  out.add('Ticket #${o.no.toString().padLeft(4, '0')}');
  out.add(DateFormat('dd/MM/yyyy HH:mm').format(o.date));
  out.add(sep);
  for (final l in o.lines) {
    out.addAll(wrap(t(l.name)));
    out.add(lr('  ${l.qty} x ${mny(l.price)}', mny(l.total)));
  }
  out.add(sep);
  out.add(lr('TOTAL', mny(o.total)));
  out.add(sep);
  out.add(c(t('Merci de votre visite !')));
  out.add(c(t('A bientôt')));
  return out;
}

Future<String?> printBluetooth(Order o) async {
  if (app.printerMac == null) return 'Aucune imprimante choisie (onglet Réglages).';
  await [Permission.bluetoothConnect, Permission.bluetoothScan].request();
  if (!await PrintBluetoothThermal.bluetoothEnabled) return 'Bluetooth désactivé.';
  if (!await PrintBluetoothThermal.connectionStatus) {
    final ok = await PrintBluetoothThermal.connect(macPrinterAddress: app.printerMac!);
    if (!ok) return "Connexion à l'imprimante impossible.";
  }
  final profile = await CapabilityProfile.load();
  final g = Generator(app.paper58 ? PaperSize.mm58 : PaperSize.mm80, profile);
  List<int> bytes = [];
  bytes += g.reset();
  for (final line in buildTicket(o, app.resto!, app.paper58 ? 32 : 48, ascii: true)) {
    bytes += g.text(line);
  }
  bytes += g.feed(2);
  bytes += g.cut();
  final ok = await PrintBluetoothThermal.writeBytes(bytes);
  return ok ? null : "Échec de l'impression.";
}

/// Impression via le service d'impression Android (PDF au format rouleau).
Future<void> printSystem(Order o) async {
  final lines = buildTicket(o, app.resto!, app.paper58 ? 32 : 48);
  final doc = pw.Document();
  final fmt = (app.paper58 ? PdfPageFormat.roll57 : PdfPageFormat.roll80)
      .copyWith(marginAll: 2 * PdfPageFormat.mm);
  doc.addPage(pw.Page(
    pageFormat: fmt,
    build: (_) => pw.Text(lines.join('\n'),
        style: pw.TextStyle(font: pw.Font.courier(), fontSize: app.paper58 ? 7.5 : 7)),
  ));
  await Printing.layoutPdf(onLayout: (_) => doc.save(), name: 'Ticket ${o.no}');
}
