import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'models.dart';
import 'printer.dart';
import 'state.dart';

final navKey = GlobalKey<NavigatorState>();
final msgKey = GlobalKey<ScaffoldMessengerState>();

void toast(String s) => msgKey.currentState?.showSnackBar(SnackBar(content: Text(s)));

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Caisse Resto',
        navigatorKey: navKey,
        scaffoldMessengerKey: msgKey,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFFB71C1C), useMaterial3: true),
        home: ListenableBuilder(
          listenable: app,
          builder: (_, __) => app.resto == null ? const SetupScreen() : const HomeScreen(),
        ),
      );
}

Widget itemImage(String? path) {
  const ph = ColoredBox(
      color: Color(0x14000000), child: Center(child: Icon(Icons.restaurant, size: 40)));
  if (path == null || path.isEmpty) return ph;
  if (path.startsWith('http')) {
    return Image.network(path, fit: BoxFit.cover, errorBuilder: (_, __, ___) => ph);
  }
  return Image.file(File(path), fit: BoxFit.cover, errorBuilder: (_, __, ___) => ph);
}

Widget field(TextEditingController c, String label, {TextInputType? kb, ValueChanged<String>? onChanged}) =>
    Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        keyboardType: kb,
        onChanged: onChanged,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );

// ---------------------------------------------------------------- Configuration
class SetupScreen extends StatefulWidget {
  final bool editing;
  const SetupScreen({super.key, this.editing = false});
  @override
  State<SetupScreen> createState() => _SetupState();
}

class _SetupState extends State<SetupScreen> {
  late final n = TextEditingController(text: app.resto?.name);
  late final a = TextEditingController(text: app.resto?.address);
  late final t = TextEditingController(text: app.resto?.phone);
  late final c = TextEditingController(text: app.resto?.currency ?? '€');

  Future<void> _save() async {
    if (n.text.trim().isEmpty) return toast('Le nom du restaurant est obligatoire.');
    await app.saveResto(Restaurant(n.text.trim(), a.text.trim(), t.text.trim(),
        c.text.trim().isEmpty ? '€' : c.text.trim()));
    if (widget.editing && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
            title: Text(widget.editing ? 'Informations du restaurant' : 'Bienvenue')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          if (!widget.editing)
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Text(
                  "Renseignez les informations de votre restaurant. Elles apparaîtront en en-tête de tous les tickets."),
            ),
          field(n, 'Nom du restaurant'),
          field(a, 'Adresse'),
          field(t, 'Téléphone', kb: TextInputType.phone),
          field(c, 'Devise (ex : €, FCFA, \$)'),
          FilledButton(onPressed: _save, child: const Text('Enregistrer')),
        ]),
      );
}

// ---------------------------------------------------------------- Accueil
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeState();
}

class _HomeState extends State<HomeScreen> {
  int i = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
            title: ListenableBuilder(
                listenable: app, builder: (_, __) => Text(app.resto?.name ?? ''))),
        body: const [CashierPage(), CatalogPage(), SettingsPage()][i],
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'Caisse'),
            NavigationDestination(icon: Icon(Icons.menu_book), label: 'Catalogue'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'Réglages'),
          ],
        ),
      );
}

// ---------------------------------------------------------------- Caisse
class CashierPage extends StatelessWidget {
  const CashierPage({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          if (app.items.isEmpty) {
            return const Center(
                child: Padding(
              padding: EdgeInsets.all(24),
              child: Text("Le catalogue est vide.\nAjoutez des articles dans l'onglet Catalogue.",
                  textAlign: TextAlign.center),
            ));
          }
          return Column(children: [
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(8),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 180,
                    childAspectRatio: .8,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8),
                itemCount: app.items.length,
                itemBuilder: (_, k) {
                  final it = app.items[k];
                  final q = app.cart[it.id] ?? 0;
                  return Card(
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () => app.add(it),
                      child: Stack(children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          Expanded(child: itemImage(it.image)),
                          Padding(
                            padding: const EdgeInsets.all(8),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(it.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text(money(it.price)),
                            ]),
                          ),
                        ]),
                        if (q > 0)
                          Positioned(
                              top: 6,
                              right: 6,
                              child: CircleAvatar(radius: 14, child: Text('$q'))),
                      ]),
                    ),
                  );
                },
              ),
            ),
            if (app.count > 0)
              Material(
                elevation: 8,
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(children: [
                      Expanded(
                          child: Text('${app.count} article(s) • ${money(app.total)}',
                              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
                      FilledButton.icon(
                        onPressed: () => showModalBottomSheet(
                            context: ctx, isScrollControlled: true, builder: (_) => const CartSheet()),
                        icon: const Icon(Icons.shopping_cart),
                        label: const Text('Panier'),
                      ),
                    ]),
                  ),
                ),
              ),
          ]);
        },
      );
}

class CartSheet extends StatelessWidget {
  const CartSheet({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) {
          final inCart = app.items.where((i) => app.cart.containsKey(i.id)).toList();
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Panier', style: Theme.of(ctx).textTheme.titleLarge),
                if (inCart.isEmpty)
                  const Padding(padding: EdgeInsets.all(24), child: Text('Panier vide'))
                else
                  Flexible(
                    child: ListView(shrinkWrap: true, children: [
                      for (final i in inCart)
                        ListTile(
                          title: Text(i.name),
                          subtitle: Text('${money(i.price)} × ${app.cart[i.id]}'),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(
                                icon: const Icon(Icons.remove_circle_outline),
                                onPressed: () => app.dec(i)),
                            Text('${app.cart[i.id]}'),
                            IconButton(
                                icon: const Icon(Icons.add_circle_outline),
                                onPressed: () => app.add(i)),
                          ]),
                        ),
                    ]),
                  ),
                const Divider(),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('TOTAL', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text(money(app.total),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ]),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: inCart.isEmpty
                        ? null
                        : () {
                            final o = app.validate();
                            Navigator.pop(ctx);
                            showTicket(o);
                          },
                    child: const Text('Valider la commande'),
                  ),
                ),
              ]),
            ),
          );
        },
      );
}

void showTicket(Order o) {
  final text = buildTicket(o, app.resto!, 32).join('\n');
  showDialog(
    context: navKey.currentContext!,
    builder: (d) => AlertDialog(
      title: Text('Commande n°${o.no} validée'),
      content: SingleChildScrollView(
          child: Text(text, style: const TextStyle(fontFamily: 'monospace', fontSize: 12))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Fermer')),
        TextButton(
            onPressed: () async {
              try {
                await printSystem(o);
              } catch (e) {
                toast('Erreur : $e');
              }
            },
            child: const Text('Imprimer (Android)')),
        FilledButton(
            onPressed: () async {
              final err = await printBluetooth(o);
              if (err != null) toast(err);
            },
            child: const Text('Imprimer (Bluetooth)')),
      ],
    ),
  );
}

// ---------------------------------------------------------------- Catalogue
class CatalogPage extends StatelessWidget {
  const CatalogPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const ItemEditor())),
          icon: const Icon(Icons.add),
          label: const Text('Ajouter'),
        ),
        body: ListenableBuilder(
          listenable: app,
          builder: (ctx, _) => ListView(padding: const EdgeInsets.only(bottom: 90), children: [
            for (final it in app.items)
              ListTile(
                leading: SizedBox(
                    width: 56,
                    height: 56,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(8), child: itemImage(it.image))),
                title: Text(it.name),
                subtitle: Text(money(it.price)),
                onTap: () => Navigator.push(
                    ctx, MaterialPageRoute(builder: (_) => ItemEditor(item: it))),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    final ok = await showDialog<bool>(
                      context: ctx,
                      builder: (d) => AlertDialog(
                        title: Text('Supprimer « ${it.name} » ?'),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.pop(d, false),
                              child: const Text('Annuler')),
                          FilledButton(
                              onPressed: () => Navigator.pop(d, true),
                              child: const Text('Supprimer')),
                        ],
                      ),
                    );
                    if (ok == true) app.deleteItem(it.id);
                  },
                ),
              ),
          ]),
        ),
      );
}

class ItemEditor extends StatefulWidget {
  final Item? item;
  const ItemEditor({super.key, this.item});
  @override
  State<ItemEditor> createState() => _ItemEditorState();
}

class _ItemEditorState extends State<ItemEditor> {
  late final n = TextEditingController(text: widget.item?.name);
  late final pr = TextEditingController(
      text: widget.item == null ? '' : widget.item!.price.toStringAsFixed(2));
  late final url = TextEditingController(
      text: (widget.item?.image ?? '').startsWith('http') ? widget.item!.image : '');
  late String? image = widget.item?.image;

  Future<void> _pick() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 900, imageQuality: 80);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = p.join(dir.path, '${DateTime.now().millisecondsSinceEpoch}${p.extension(x.path)}');
    await File(x.path).copy(dest);
    setState(() {
      image = dest;
      url.clear();
    });
  }

  Future<void> _save() async {
    final price = double.tryParse(pr.text.replaceAll(',', '.').trim());
    if (n.text.trim().isEmpty || price == null || price < 0) {
      return toast('Nom et prix valides obligatoires.');
    }
    await app.upsertItem(Item(
      id: widget.item?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: n.text.trim(),
      price: price,
      image: image,
    ));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.item == null ? 'Nouvel article' : "Modifier l'article")),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          field(n, 'Nom du plat'),
          field(pr, 'Prix', kb: const TextInputType.numberWithOptions(decimal: true)),
          AspectRatio(
              aspectRatio: 16 / 9,
              child: ClipRRect(borderRadius: BorderRadius.circular(12), child: itemImage(image))),
          const SizedBox(height: 8),
          OutlinedButton.icon(
              onPressed: _pick,
              icon: const Icon(Icons.photo_library),
              label: const Text('Importer depuis la galerie')),
          const SizedBox(height: 12),
          field(url, "…ou coller l'URL d'une image (https://…)",
              kb: TextInputType.url,
              onChanged: (v) => setState(() => image = v.trim().isEmpty ? null : v.trim())),
          FilledButton(onPressed: _save, child: const Text('Enregistrer')),
        ]),
      );
}

// ---------------------------------------------------------------- Réglages
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _pickPrinter(BuildContext ctx) async {
    await [Permission.bluetoothConnect, Permission.bluetoothScan].request();
    final list = await PrintBluetoothThermal.pairedBluetooths;
    if (!ctx.mounted) return;
    showDialog(
      context: ctx,
      builder: (d) => SimpleDialog(
        title: const Text('Imprimantes Bluetooth appairées'),
        children: list.isEmpty
            ? [
                const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                        "Aucune. Appairez d'abord l'imprimante dans les réglages Bluetooth d'Android."))
              ]
            : [
                for (final b in list)
                  SimpleDialogOption(
                    onPressed: () {
                      app.setPrinter(b.macAdress, b.name);
                      Navigator.pop(d);
                    },
                    child: Text('${b.name}\n${b.macAdress}'),
                  ),
              ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (ctx, _) => ListView(children: [
          ListTile(
            leading: const Icon(Icons.store),
            title: const Text('Informations du restaurant'),
            subtitle: const Text("Nom, adresse, téléphone (en-tête des tickets)"),
            onTap: () => Navigator.push(
                ctx, MaterialPageRoute(builder: (_) => const SetupScreen(editing: true))),
          ),
          ListTile(
            leading: const Icon(Icons.print),
            title: const Text('Imprimante Bluetooth ESC/POS'),
            subtitle: Text(app.printerName ?? 'Aucune sélectionnée'),
            onTap: () => _pickPrinter(ctx),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.receipt_long),
            title: const Text('Papier 58 mm'),
            subtitle: Text(app.paper58 ? '32 caractères par ligne' : 'Papier 80 mm : 48 caractères'),
            value: app.paper58,
            onChanged: app.setPaper58,
          ),
          ListTile(
            leading: const Icon(Icons.bug_report_outlined),
            title: const Text("Ticket de test (Bluetooth)"),
            onTap: () async {
              final err = await printBluetooth(
                  Order(0, DateTime.now(), const [Line('Article test', 1.5, 2)]));
              toast(err ?? 'Ticket envoyé.');
            },
          ),
        ]),
      );
}
