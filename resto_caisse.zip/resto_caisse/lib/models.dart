class Restaurant {
  final String name, address, phone, currency;
  const Restaurant(this.name, this.address, this.phone, this.currency);
  Map<String, dynamic> toJson() =>
      {'name': name, 'address': address, 'phone': phone, 'currency': currency};
  factory Restaurant.fromJson(Map<String, dynamic> j) =>
      Restaurant(j['name'], j['address'], j['phone'], j['currency'] ?? '€');
}

class Item {
  final String id, name;
  final double price;
  final String? image; // chemin local ou URL http(s)
  const Item({required this.id, required this.name, required this.price, this.image});
  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'price': price, 'image': image};
  factory Item.fromJson(Map<String, dynamic> j) => Item(
      id: j['id'], name: j['name'], price: (j['price'] as num).toDouble(), image: j['image']);
}

class Line {
  final String name;
  final double price;
  final int qty;
  const Line(this.name, this.price, this.qty);
  double get total => price * qty;
}

class Order {
  final int no;
  final DateTime date;
  final List<Line> lines;
  Order(this.no, this.date, this.lines);
  double get total => lines.fold<double>(0, (s, l) => s + l.total);
}
