#!/usr/bin/env bash
# Génère le dossier android/ et ajoute les permissions nécessaires.
set -e
if [ ! -d android ]; then
  flutter create --org com.monresto --project-name resto_caisse --platforms android /tmp/gen
  cp -r /tmp/gen/android ./android
fi
M=android/app/src/main/AndroidManifest.xml
if ! grep -q BLUETOOTH_CONNECT "$M"; then
  PERMS='<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>\n    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>\n    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>\n    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30"/>'
  sed -i "s#<application#$PERMS\n    <application#" "$M"
  sed -i 's#android:label="[^"]*"#android:label="Caisse Resto"#' "$M"
fi
echo "OK : projet Android prêt."
