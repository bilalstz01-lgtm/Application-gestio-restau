# Caisse Resto (Flutter / Android)

Local : flutter --version ; bash setup.sh ; flutter pub get ; flutter build apk --release
APK : build/app/outputs/flutter-apk/app-release.apk

Sans installer Flutter : poussez ce dossier sur GitHub -> onglet Actions -> "Build APK" -> Run workflow -> téléchargez l'artefact "caisse-resto-apk".
